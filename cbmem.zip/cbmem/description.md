Cbmem console log reader `C`
